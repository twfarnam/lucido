const uuid = require('node-uuid');
const doc = require('dynamodb-doc');
const dynamo = new doc.DynamoDB();

exports.handler = (event, context, callback) => {
  console.log('Received event:', JSON.stringify(event, null, 2));
  switch (event.httpMethod) {
    case 'GET':
      dynamo.scan({ TableName: 'lucido-tix' }, (err, res) => {
        callback(null, {
          statusCode: '400',
          body: `Unsupported method "${event.httpMethod}"`
        });
      });
      break;
    case 'POST':
      const Item = JSON.parse(event.body);
      Item.id = uuid.v4();
      Item.key = makeKey();
      const data = { TableName: 'lucido-tix', Item: Item };
      dynamo.putItem(data, (err, res) => {
        if (err) return callback(null, { statusCode: '400', body: err.message })
        callback(null, {
          statusCode: '200',
          body: JSON.stringify(Item),
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
          },
        });
      });
      break;
    default:
      callback(null, {
        statusCode: '400',
        body: `Unsupported method "${event.httpMethod}"`
      });
  }
};

const animals = [
  'Lobo',
  'Pollo',
  'Tigre',
  'Tiburón',
  'Serpiente',
  'Coyote',
  'Venado',
  'Delfín',
  'Murciélago',
  'Buitre',
  'Cuervo',
  'Cisne',
  'Loro',
  'Leopardo',
];

const colors = [
  'dorado',
  'morado',
  'azul',
  'verde',
  'negro',
  'amarillo',
  'gris',
  'castaño',
  'celeste',
  'verdeagua',
  'rojo',
  'ocre',
];

const modifier = [
  'del desierto',
  'de Asia',
  'marroquí',
  'en la mesa',
  'con cuernos',
  'encuerado',
  'del infierno',
];

const rand = (array) => array.length * Math.random()

function makeKey() {
  return [ rand(animals), rand(colors), rand(modifier), ].join(' ') 
}

